#ifndef __CONTROL_H
#define __CONTROL_H

float Balance(float MED,float Angle,short gyro_z);
float Velocity(float Target,float Encoder_Left,float Encoder_Right);
float Turn(short gyro_z);

int Read_EncoderA(void);
int Read_EncoderB(void);

void Limit(float *motoA,float *motoB);
void Load(float* MOTO1,float* MOTO2);

#define PWM_MAX 7200
#define PWM_MIN -7200
#endif
